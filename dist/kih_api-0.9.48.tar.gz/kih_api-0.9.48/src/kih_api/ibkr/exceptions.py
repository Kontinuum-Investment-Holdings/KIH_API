class IBKR_APITimeOutException(Exception):
    pass


class MarketDataNotAvailableException(Exception):
    pass
